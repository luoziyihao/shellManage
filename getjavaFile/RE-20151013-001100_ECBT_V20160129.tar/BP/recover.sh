echo "recover package start ... ..."

rm -rf /usr/ebank/buildit/app/BPServer/EbankTask/config/SYSDATA/TASKS/PoolMonthDetailTask.xml

rm -rf /usr/ebank/buildit/app/BPServer/EbankTask/classes/com/citic/bpserver/task/corp/impl/PoolMonthDetailCmp.class
rm -rf /usr/ebank/buildit/app/BPServer/EbankTask/classes/com/citic/bpserver/dao/task/corp/impl/PoolMonthDetailDao.class
rm -rf /usr/ebank/buildit/app/BPServer/EbankTask/classes/com/citic/bpserver/bean/corp/PlPoolTrnInfoBean.class
rm -rf /usr/ebank/buildit/app/BPServer/EbankTask/classes/com/citic/bpserver/task/corp/PoolMonthDetailTask.class
rm -rf /usr/ebank/buildit/app/BPServer/EbankTask/classes/com/citic/common/RecordUtil.class

cp -rf ./bak/* /usr/ebank/buildit/app/BPServer/EbankTask/

echo "recover package end."
