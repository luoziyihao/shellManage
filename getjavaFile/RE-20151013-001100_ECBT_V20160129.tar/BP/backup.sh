echo "backup package start ... ..."

mkdir -p bak
mkdir -p ./bak/classes/com/citic/bpserver/constant/task/
mkdir -p ./bak/classes/com/citic/common/
mkdir -p ./bak/config/SYSDATA/

cp -rf /usr/ebank/buildit/app/BPServer/EbankTask/config/SYSDATA/Task.xml ./bak/config/SYSDATA/

cp -rf /usr/ebank/buildit/app/BPServer/EbankTask/classes/com/citic/bpserver/constant/task/CashConstant.class ./bak/classes/com/citic/bpserver/constant/task/
cp -rf /usr/ebank/buildit/app/BPServer/EbankTask/classes/com/citic/common/BpUtil.class ./bak/classes/com/citic/common/

echo "backup package end."
