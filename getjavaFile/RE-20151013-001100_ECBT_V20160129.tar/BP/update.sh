echo "update package start ... ..."

cp -rf config /usr/ebank/buildit/app/BPServer/EbankTask/
cp -rf classes /usr/ebank/buildit/app/BPServer/EbankTask/

echo "update package end."
