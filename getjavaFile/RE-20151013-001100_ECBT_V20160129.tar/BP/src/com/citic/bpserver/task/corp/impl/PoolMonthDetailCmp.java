package com.citic.bpserver.task.corp.impl;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.citic.bpframe.SysInfo;
import com.citic.bpserver.bean.corp.PlPoolTrnInfoBean;
import com.citic.bpserver.constant.task.AccChkConstant;
import com.citic.bpserver.constant.task.CashConstant;
import com.citic.bpserver.constant.task.ETConstant;
import com.citic.bpserver.dao.task.corp.impl.PoolMonthDetailDao;
import com.citic.bpserver.task.accchk.ITaskModule;
import com.citic.bpserver.task.accchk.data.CheckContext;
import com.citic.common.BpUtil;
import com.citic.common.Common;
import com.lsy.baselib.exception.AppException;
import com.lsy.baselib.log.CustomLogger;
import com.lsy.baselib.service.ServiceRegistry;
import com.lsy.baselib.util.Constant;
import com.lsy.baselib.util.MyDate;
import com.lsy.baselib.xml.XmlDocument;
import com.lsy.baselib.xml.element.XmlIni;
import com.lsy.baselib.xml.element.XmlIniSection;
import com.lsy.baselib.xml.element.XmlList;
import com.lsy.baselib.xml.element.XmlRow;
import com.sun.xml.internal.fastinfoset.util.StringArray;
/**
 * 
* <p> Description:�����Թ���-�ֽ��ί���±�-�ֽ��ί���±����غ�̨�����ļ��������  </p>
* <p> Copyright: Copyright (c) 2015 </p>
* <p> Create Date: 2015-12-18 </p>
* <p> Company: CITIC BANK </p>
* @author raoxiang
* @version $Id: PoolMonthDetailCmp.java v 1.0 2015-12-18 ����11:46:21 raoxiang Exp $
 */
public class PoolMonthDetailCmp implements ITaskModule {
    /**
     * ��־
     */
    CustomLogger logger = (CustomLogger) ServiceRegistry.getInstance().lookup(
            Constant.BUS_LOGGER);
    /**
     * ���ί���±��������ݿ⴦����
     */
    private PoolMonthDetailDao poolMonthDetailDao = new PoolMonthDetailDao();
   
    /**
     * �ļ�����·��
     */
    private String localSavePath = "";
    
    /**
     * ���ݿ�����driver
     */
    private String driver = "";
    
    /**
     * ���ݿ�����url
     */
    private String url = "";
    
    /**
     * ���ݿ�����userName
     */
    private String userName = "";
    
    /**
     * ���ݿ�����passWord
     */
    private String passWord = "";
    
    /**
     *  ִ�������ύ�ı���
     */
    private int excuteBathNum = 1000;
    
    /**
     *  ������ϸ�ļ����Ƶĳ���
     */
    private int transDetFileNameLength = 24;
    
    /**
     * ģ�����ִ��ǰ��Ԥ����
     *
     */
    public boolean beforeProc(CheckContext context) throws AppException {
        logger.info("PoolMonthDetailCmp beforeProc start...");
        //��ʼ���ļ�����·��
        ServiceRegistry registry = ServiceRegistry.getInstance();
        SysInfo sysInfo = (SysInfo) registry.lookup(Constant.SYS_INFO);
        localSavePath = context.getLocalFliePath();
        //��ʼ�����ݿ���������
        String dbCfgPath = sysInfo.getSysRoot() + File.separator
            + AccChkConstant.COMM_CONFIG_PATH + File.separator + "DBConfig.xml";
        XmlIni dbCfg = XmlDocument.loadXmlIni(dbCfgPath);
        XmlIniSection sec = dbCfg.getSection(ETConstant.CORPOOL);
        driver = sec.getFieldValue("driver");
        url = sec.getFieldValue("url");
        userName = sec.getFieldValue("user");
        passWord = sec.getFieldValue("password");
        logger.info("PoolMonthDetailCmp beforeProc end...");
        return true;
    }

    /**
     * ��������������ϸ��Ϣ
     *
     */
    public boolean process(CheckContext context) throws AppException {
        logger.info("PoolMonthDetailCmp process start...");
        XmlList sttList = null;
        File transFilesDir = null;
        File[] transFiles = null;
        File transFile = null;
        File transDetailFile = null;
        String fileDate = "";
        String fileName = "";
        FileReader reader = null;
        BufferedReader br = null;
        FileReader reader2 = null;
        BufferedReader br2 = null;
        String stt = "";
        String detailMonth = "";
        //�����洢Ŀ¼�µ������ļ�
        transFilesDir = new File(localSavePath);
        transFiles = transFilesDir.listFiles();
        for (int i = 0; i < transFiles.length; i++) {
            stt = ETConstant.DET_STT_IMPORT_DETAIL_FAIL; //������ϸ״̬ 1�����뽻����ϸ��Ϣ��ʧ��
            boolean upFlag = true;
            Connection con = null;
            transFile = transFiles[i];
            fileName = transFile.getName();
            //��ȡ.dat�ļ�
            if (fileName.startsWith(CashConstant.ODS_TRANS_INFO_PRE_FILENAME) 
                    && fileName.endsWith(".dat") && fileName.length() == transDetFileNameLength) {
                transDetailFile = transFile;
                fileDate = fileName.substring(12, 20);
                logger.info("TransDetail dat File Name: " + fileName);
                try {
                    logger.info("TransDetail dat File Time: " + transDetailFile.lastModified());
                    sttList = poolMonthDetailDao.qryTranDetailStt( fileDate); //��ѯ������ϸ״̬��Ϣ
                    //���ļ���Ӧ��״̬������������µļ�¼��״̬Ϊ0:δ����
                    detailMonth = getDetailMonth(fileDate);
                    if (sttList.size() == 0) {
                        stt = ETConstant.DET_STT_NOT_MANAGE;
                        poolMonthDetailDao.insertTranDetailStt(fileDate,detailMonth, stt);
                    } else if (sttList.size() == 1) {
                        stt = ((XmlRow)(sttList.getRowIterator().next())).getFieldValue("STT");
                    } else{
                        //$ERROR:TD00035==�ֽ�����ֽ��ί���±��ļ�״̬�쳣,ͬһ�·ݴ��ڶ���ļ�==�ֽ�����ֽ��ί���±��ļ�״̬�쳣,ͬһ�·ݴ��ڶ���ļ�
                        throw new AppException("TD00035");
                    }
                    if (ETConstant.DET_STT_NOT_MANAGE.equals(stt) || ETConstant.DET_STT_IMPORT_DETAIL_FAIL.equals(stt)) {
                        logger.info("Import TransDetail dat File for: " + fileName + " start!");
                        stt = ETConstant.DET_STT_IMPORT_DETAIL_SUCCESS; //������ϸ״̬ 2�����뽻����ϸ��Ϣ���ɹ�
                        reader = new FileReader(transDetailFile);
                        br = new BufferedReader(reader);
                        String lineString = ""; //һ�н�����ϸ
                        String[] stringArray = null; //��ʽ����Ľ�����ϸ����
                       
                        int linenum = 1;
                        logger.info("Loop 1 for TransDetail dat File : " + fileName + " start!");
                        //�����ļ���ȡ�˺ź����ڲ�У��
                        while ((lineString = br.readLine()) != null) {
                            //�±���ϸ ��ϸ��Ϣһ���� 20���� ���һ������Ч
                            stringArray = formatLineString(lineString, new int[] {8,12});
                            detailDataCheck(stringArray,linenum++,fileName);
                        }
                        
                        logger.info("clear transdet for TransDetail dat File : " + fileName + " start!");
                        //ɾ��������ϸ��Ϣ������Ӧ������
                        poolMonthDetailDao.deleteDetailInfo(detailMonth);
                        logger.info("clear transdet for TransDetail dat File : " + fileName + " end!");
                        PlPoolTrnInfoBean plPoolTrnInfoBean = null;
                        int k = 0;
                        List<PlPoolTrnInfoBean> transDetailInfoDAOBeanList = new ArrayList<PlPoolTrnInfoBean>();
                        //���¶�ȡ�ļ������뽻����ϸ��Ϣ��
                        Class.forName(driver);
                        con = DriverManager.getConnection(url, userName, passWord);
                        reader2 = new FileReader(transDetailFile);
                        br2 = new BufferedReader(reader2);
                        logger.info("Loop 2 for TransDetail dat File : " + fileName + " start!");
                        while ((lineString = br2.readLine()) != null) {
                            k++;
                            stringArray = formatLineString(lineString, new int[] {8,12}); stringArray = formatLineString(lineString, new int[] {8,12});
                            plPoolTrnInfoBean = initDetailBean(stringArray,detailMonth);
                            transDetailInfoDAOBeanList.add(plPoolTrnInfoBean);
                            //�������뽻����ϸ��Ϣ��
                            if (k % excuteBathNum == 0) {
                                poolMonthDetailDao.insertTranDetailInfo(con, transDetailInfoDAOBeanList, (k - excuteBathNum));
                                transDetailInfoDAOBeanList.clear();
                                logger.info("transDetailInfoDAOBeanList size:" + transDetailInfoDAOBeanList.size());
                            }
                         }
                        //�������뿪ʼ�к�
                        int lineNo = 0;
                        if (lineNo > excuteBathNum) {
                            lineNo = k - excuteBathNum;
                        }
                        poolMonthDetailDao.insertTranDetailInfo(con, transDetailInfoDAOBeanList, lineNo);
                        logger.info("Insert TransDetail dat File for: " + fileName + " Number: " + k);
                        logger.info("Import TransDetail dat File for: " + fileName + " end!");
                    } else {
                        upFlag = false;
                    }
                } catch (AppException ex) {
                    logger.error("TransDetail dat File Name: " + fileName);
                    logger.error(ex.getStackTrace(), ex);
                    stt = ETConstant.DET_STT_IMPORT_DETAIL_FAIL; //������ϸ״̬ 1�����뽻����ϸ��Ϣ��ʧ��
                } catch (Exception ex) {
                    logger.error("TransDetail dat File Name: " + fileName);
                    logger.error(ex.getStackTrace(), ex);
                    stt = ETConstant.DET_STT_IMPORT_DETAIL_FAIL; //������ϸ״̬ 1�����뽻����ϸ��Ϣ��ʧ��
                } finally {
                    try {
                        poolMonthDetailDao.updateTranDetailStt(fileDate, stt, upFlag);
                    } catch (AppException e) {
                        logger.error(e.getStackTrace(), e);
                    }
                    if (con != null) {
                        try {
                            con.close();
                        } catch (SQLException e) {
                            logger.error(e.getStackTrace(), e);
                        }
                    }
                    if (br != null) {
                        try {
                            br.close();
                        } catch (IOException e) {
                            logger.error(e.getStackTrace(), e);
                        }
                    }
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            logger.error(e.getStackTrace(), e);
                        }
                    }
                    if (br2 != null) {
                        try {
                            br2.close();
                        } catch (IOException e) {
                            logger.error(e.getStackTrace(), e);
                        }
                    }
                    if (reader2 != null) {
                        try {
                            reader2.close();
                        } catch (IOException e) {
                            logger.error(e.getStackTrace(), e);
                        }
                    }
                }
            }
        }
        logger.info("PoolMonthDetailCmp process end...");
        return true;
    }

    /**
    * Title: initDetailBean
    * Description: ��ʼ�� �±���Ϣbean ���·��ļ��л�ȡ 19���ֶ� �·��ļ���20���ֶ���Ч �����������Ϣ�ɴ����������
    * @param stringArray
     * @param detailMonth 
    * @return 
    * 2015-12-20 ����12:53:27
    * author: raoxiang 
    */
    private PlPoolTrnInfoBean initDetailBean(String[] stringArray, String detailMonth) {
        PlPoolTrnInfoBean bean = new PlPoolTrnInfoBean();
        int i = 0;
        for(int j = 0; j <stringArray.length; j++){
            stringArray[j] = BpUtil.nullToSpace(stringArray[j]);
        }
        bean.setBankno(Common.isoToGBK(stringArray[i++]));
        bean.setPoolid(Common.isoToGBK(stringArray[i++]));
        bean.setPoolname(Common.isoToGBK(stringArray[i++]));
        bean.setBorsetaccount(Common.isoToGBK(stringArray[i++]));
        bean.setBorsetaccountnm(Common.isoToGBK(stringArray[i++]));
        bean.setConsetaccount(Common.isoToGBK(stringArray[i++]));
        bean.setConsetaccountnm(Common.isoToGBK(stringArray[i++]));
        bean.setLastmonthbalance(Common.isoToGBK(stringArray[i++]));
        bean.setDetaildate(Common.isoToGBK(stringArray[i++]));
        bean.setDpamt(Common.isoToGBK(stringArray[i++]));
        bean.setLnamt(Common.isoToGBK(stringArray[i++]));
        bean.setAmtsurplus(Common.isoToGBK(stringArray[i++]));
        bean.setSurpluschangedate(Common.isoToGBK(stringArray[i++]));
        bean.setDprate(Common.isoToGBK(stringArray[i++]));
        bean.setLnrate(Common.isoToGBK(stringArray[i++]));
        bean.setInterest(Common.isoToGBK(stringArray[i++]));
        bean.setTotalinterest(Common.isoToGBK(stringArray[i++]));
        bean.setDpinterest(Common.isoToGBK(stringArray[i++]));
        bean.setLninterest(Common.isoToGBK(stringArray[i++]));
        
	    bean.setDetailmonth(detailMonth);
        return bean;
    }

    private void detailDataCheck(String[] stringArray, int lineNum, String fileName) throws AppException {
	    String fatherAccNo= stringArray[5];
	    String childAccNo = stringArray[3];
	    String tranDate = stringArray[8];
	    
        if (BpUtil.isEmpty(fatherAccNo) || fatherAccNo.length() != 19) {
            logger.error("TransDetail dat File" + fileName + " Error in line : " + (lineNum));
            //$ERROR:TD00014==ǩԼ�˺Ŵ���==ǩԼ�˺Ŵ���
            throw new AppException("TD00014");
        }
                    
        if (BpUtil.isEmpty(childAccNo)| childAccNo.length() != 19) {
            logger.error("TransDetail dat File" + fileName + " Error in line : " + (lineNum));
            //$ERROR:TD00014==ǩԼ�˺Ŵ���==ǩԼ�˺Ŵ���
            throw new AppException("TD00014");
        }
        if (BpUtil.isEmpty(tranDate) || !BpUtil.chcekDateFormat(tranDate)) {
            logger.error("TransDetail dat File" + fileName + " Error in line : " + lineNum);
            //$ERROR:TD00015==�������ڴ���==�������ڴ���
            throw new AppException("TD00015");
        }
    }


    /**
    * Title: getDetailMonth
    * Description: ���ش���ֵǰһ�µ����·�
    * @param fileDate
    * @return 
    * date: 2015-12-18 ����05:02:14
    * @author raoxiang
     * @throws ParseException 
    */
    private String getDetailMonth(String fileDate)throws AppException, ParseException {
      
        //�������ַ���ת��Ϊ calendar 
        Calendar fileCalendar = strToCalender(fileDate);
        //ȡ�ϸ���
        fileCalendar.add(Calendar.MONTH, -1);
        //�����ַ�����ʽ����� ����ȡ�·���Ϣ
        return new SimpleDateFormat("yyyyMMdd").format(fileCalendar.getTime()).substring(0,6);
    }

    /**
     * ģ��processִ�гɹ���ĺ�������,ɾ�� �������µ� 6����ǰ�� ��ʷ�ļ�
     *
     */
    public boolean afterProc(CheckContext context) throws AppException {
        //��������ڵ��ļ� ����6����ǰ���·ݵ��ļ��� ��Ϊ����
       File[] transFiles = new File(localSavePath).listFiles();
       String fileDateStr = "";
       Date fileDate; 
       Calendar filecCalendar ;
       int divMonth;
       for (int i = 0; i < transFiles.length; i++) {
           if (transFiles[i].getName().startsWith(CashConstant.ODS_TRANS_INFO_PRE_FILENAME)) {
               
               //��ȡ�����ַ���
               fileDateStr = transFiles[i].getName().substring(12, 20);
               //�������ַ���ת��Ϊcalender
               filecCalendar = strToCalender(fileDateStr);
               filecCalendar.add(Calendar.MONTH, 6);
               if(filecCalendar.compareTo(MyDate.getInstance()) <= 0){
                   try {
                       transFiles[i].delete();
                       logger.info("Clear file : " + transFiles[i].getName() + " success !");
                   } catch (Exception e) {
                       logger.error("Clear file : " + transFiles[i].getName() + " fail !");
                       logger.error(e.getStackTrace(), e);
                   }
               }
           }
       
        }
       return true;
    }
    
   
    /**
    * Title: strToCalender
    * Description: �� �����ַ���ת��Ϊ Calender
    * @return 
    * date: 2015-12-25 ����09:57:07
    * @author raoxiang
     * @param fileDateStr 
    */
    private Calendar strToCalender(String fileDateStr) throws AppException {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(BpUtil.strToDate(fileDateStr));
        return calendar;
    }

    /**
     * 
     * @param lineString �����ı�
     * @param subArr ��Ҫȥ��β׺ '.',��ǰ׺  '+' ����������
     * @return
     * @throws AppException
     */
    public String[] formatLineString(String lineString, int[] subArr) 
        throws AppException {
        String[] stringArray = lineString.split(ETConstant.SRC_DET_FILE_TOKEN);
        int index = 0;
        
        //ȥ�ո�
        for (int i = 0; i < stringArray.length; i++) {
            stringArray[i] = stringArray[i].trim();
        }
        //��Ҫȥ��β׺ '.',��ǰ׺  '+' ����������
        for (int j = 0; j < subArr.length; j++) {
            index = subArr[j];
            if (!BpUtil.isEmpty(stringArray[index])) {
                stringArray[index] = stringArray[index].substring(1, stringArray[index].length() - 1);
            }
        }
        return stringArray;
    } 
}
