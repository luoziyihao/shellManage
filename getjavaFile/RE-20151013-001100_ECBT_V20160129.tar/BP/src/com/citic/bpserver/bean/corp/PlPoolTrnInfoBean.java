package com.citic.bpserver.bean.corp;

/**
* Title: PlPoolTrnInfoBean
* Description: �ֽ���±���Ϣ��bean
* Copyright: Copyright (c) 2015
* Company: com.citic.bank
* @author raoxiang
* @date 2015-12-20 ����12:37:06
* @version 1.0
*/
public class PlPoolTrnInfoBean{
    
    //�ӹ�˾�˺�
    private String borsetaccount;

    //ĸ��˾�˺�
    private String consetaccount;

    //��ϸ����
    private String detaildate;

    //��ϸ�·�
    private String detailmonth;

    //���к�
    private String bankno;

    //�ֽ��ID
    private String poolid;

    //�ֽ������
    private String poolname;

    //�ӹ�˾����
    private String borsetaccountnm;

    //ĸ��˾����
    private String consetaccountnm;

    //���µ����
    private String lastmonthbalance;

    //ί�����ĸ��˾��
    private String dpamt;

    //ί������ĸ��˾��
    private String lnamt;

    //ί��ί���ۼ����
    private String amtsurplus;

    //���䶯����
    private String surpluschangedate;

    //ί������(%)
    private String dprate;

    //ί������(%)
    private String lnrate;

    //ί���ί����Ϣ
    private String interest;

    //�ۼ�ί��ί����Ϣ
    private String totalinterest;

    //�ۼ�ί����Ϣ
    private String dpinterest;

    //�ۼ�ί����Ϣ
    private String lninterest;

    /**
    * Title: 
    * Description:  
    */
    public PlPoolTrnInfoBean() {
        super();
        this.borsetaccount = "";
        this.consetaccount = "";
        this.detaildate = "";
        this.detailmonth = "";
        this.bankno = "";
        this.poolid = "";
        this.poolname = "";
        this.borsetaccountnm = "";
        this.consetaccountnm = "";
        this.lastmonthbalance = "";
        this.dpamt = "";
        this.lnamt = "";
        this.amtsurplus = "";
        this.surpluschangedate = "";
        this.dprate = "";
        this.lnrate = "";
        this.interest = "";
        this.totalinterest = "";
        this.dpinterest = "";
        this.lninterest = "";
    }

    /**
     * @return the borsetaccount
     */
    public String getBorsetaccount() {
        return borsetaccount;
    }

    /**
     * @param borsetaccount the borsetaccount to set
     */
    public void setBorsetaccount(String borsetaccount) {
        this.borsetaccount = borsetaccount;
    }

    /**
     * @return the consetaccount
     */
    public String getConsetaccount() {
        return consetaccount;
    }

    /**
     * @param consetaccount the consetaccount to set
     */
    public void setConsetaccount(String consetaccount) {
        this.consetaccount = consetaccount;
    }

    /**
     * @return the detaildate
     */
    public String getDetaildate() {
        return detaildate;
    }

    /**
     * @param detaildate the detaildate to set
     */
    public void setDetaildate(String detaildate) {
        this.detaildate = detaildate;
    }

    /**
     * @return the detailmonth
     */
    public String getDetailmonth() {
        return detailmonth;
    }

    /**
     * @param detailmonth the detailmonth to set
     */
    public void setDetailmonth(String detailmonth) {
        this.detailmonth = detailmonth;
    }

    /**
     * @return the bankno
     */
    public String getBankno() {
        return bankno;
    }

    /**
     * @param bankno the bankno to set
     */
    public void setBankno(String bankno) {
        this.bankno = bankno;
    }

    /**
     * @return the poolid
     */
    public String getPoolid() {
        return poolid;
    }

    /**
     * @param poolid the poolid to set
     */
    public void setPoolid(String poolid) {
        this.poolid = poolid;
    }

    /**
     * @return the poolname
     */
    public String getPoolname() {
        return poolname;
    }

    /**
     * @param poolname the poolname to set
     */
    public void setPoolname(String poolname) {
        this.poolname = poolname;
    }

    /**
     * @return the borsetaccountnm
     */
    public String getBorsetaccountnm() {
        return borsetaccountnm;
    }

    /**
     * @param borsetaccountnm the borsetaccountnm to set
     */
    public void setBorsetaccountnm(String borsetaccountnm) {
        this.borsetaccountnm = borsetaccountnm;
    }

    /**
     * @return the consetaccountnm
     */
    public String getConsetaccountnm() {
        return consetaccountnm;
    }

    /**
     * @param consetaccountnm the consetaccountnm to set
     */
    public void setConsetaccountnm(String consetaccountnm) {
        this.consetaccountnm = consetaccountnm;
    }

    /**
     * @return the lastmonthbalance
     */
    public String getLastmonthbalance() {
        return lastmonthbalance;
    }

    /**
     * @param lastmonthbalance the lastmonthbalance to set
     */
    public void setLastmonthbalance(String lastmonthbalance) {
        this.lastmonthbalance = lastmonthbalance;
    }

    /**
     * @return the dpamt
     */
    public String getDpamt() {
        return dpamt;
    }

    /**
     * @param dpamt the dpamt to set
     */
    public void setDpamt(String dpamt) {
        this.dpamt = dpamt;
    }

    /**
     * @return the lnamt
     */
    public String getLnamt() {
        return lnamt;
    }

    /**
     * @param lnamt the lnamt to set
     */
    public void setLnamt(String lnamt) {
        this.lnamt = lnamt;
    }

    /**
     * @return the amtsurplus
     */
    public String getAmtsurplus() {
        return amtsurplus;
    }

    /**
     * @param amtsurplus the amtsurplus to set
     */
    public void setAmtsurplus(String amtsurplus) {
        this.amtsurplus = amtsurplus;
    }

    /**
     * @return the surpluschangedate
     */
    public String getSurpluschangedate() {
        return surpluschangedate;
    }

    /**
     * @param surpluschangedate the surpluschangedate to set
     */
    public void setSurpluschangedate(String surpluschangedate) {
        this.surpluschangedate = surpluschangedate;
    }

    /**
     * @return the dprate
     */
    public String getDprate() {
        return dprate;
    }

    /**
     * @param dprate the dprate to set
     */
    public void setDprate(String dprate) {
        this.dprate = dprate;
    }

    /**
     * @return the lnrate
     */
    public String getLnrate() {
        return lnrate;
    }

    /**
     * @param lnrate the lnrate to set
     */
    public void setLnrate(String lnrate) {
        this.lnrate = lnrate;
    }

    /**
     * @return the interest
     */
    public String getInterest() {
        return interest;
    }

    /**
     * @param interest the interest to set
     */
    public void setInterest(String interest) {
        this.interest = interest;
    }

    /**
     * @return the totalinterest
     */
    public String getTotalinterest() {
        return totalinterest;
    }

    /**
     * @param totalinterest the totalinterest to set
     */
    public void setTotalinterest(String totalinterest) {
        this.totalinterest = totalinterest;
    }

    /**
     * @return the dpinterest
     */
    public String getDpinterest() {
        return dpinterest;
    }

    /**
     * @param dpinterest the dpinterest to set
     */
    public void setDpinterest(String dpinterest) {
        this.dpinterest = dpinterest;
    }

    /**
     * @return the lninterest
     */
    public String getLninterest() {
        return lninterest;
    }

    /**
     * @param lninterest the lninterest to set
     */
    public void setLninterest(String lninterest) {
        this.lninterest = lninterest;
    }

    
}