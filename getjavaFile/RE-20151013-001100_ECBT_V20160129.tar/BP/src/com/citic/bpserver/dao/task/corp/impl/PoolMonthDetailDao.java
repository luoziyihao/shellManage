package com.citic.bpserver.dao.task.corp.impl;

import java.math.BigDecimal;
import java.sql.BatchUpdateException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.citic.bpserver.bean.corp.PlPoolTrnInfoBean;
import com.citic.bpserver.constant.task.CashConstant;
import com.citic.bpserver.dao.task.corp.BizDAO;
import com.citic.common.BpUtil;
import com.citic.common.RecordUtil;
import com.citic.ucpframe.ext.dao.sql.IndexQuery;
import com.citic.ucpframe.ext.dao.sql.IndexUpdate;
import com.citic.ucpframe.ext.data.RecordList;
import com.lsy.baselib.exception.AppException;
import com.lsy.baselib.log.CustomLogger;
import com.lsy.baselib.service.ServiceRegistry;
import com.lsy.baselib.util.Constant;
import com.lsy.baselib.util.MyDate;
import com.lsy.baselib.xml.element.XmlList;

/**
 * <p> Description:  </p>
 * <p> Copyright: Copyright (c) 2015 </p>
 * <p> Create Date: 2015-12-18 </p>
 * <p> Company: CITIC BANK </p>
 * @author raoxiang
 * @version $Id: PoolMonthDetailDao.java v 1.0 2015-12-18 ����04:00:41 raoxiang Exp $
 */
public class PoolMonthDetailDao extends BizDAO{

    /**
     * ��־����
     */
    CustomLogger logger = (CustomLogger) ServiceRegistry.getInstance()
    .lookup(Constant.DAO_LOGGER);

    /**
    * Title: qryTranDetailStt
    * Description: �ֽ�����ֽ��ί���±��ļ�״̬��ѯ
    * @param fileDate
    * @return 
    * date: 2015-12-18 ����04:05:39
    * @author raoxiang
    */
    public XmlList qryTranDetailStt(String fileDate) throws AppException{
        // ���������
        RecordList rs = null;
        // ƴװsql
        StringBuilder builder = new StringBuilder();
        builder.append(" SELECT ");
        builder.append(" PTFS_STT STT ");
        builder.append(" FROM ");
        builder.append(" PL_TRN_FILE_STT ");
        builder.append(" WHERE PTFS_FILEDATE = ? ");
        try {
            IndexQuery query = dbSession.createIndexQuery(builder.toString());
            int i = 1;
            query.setDate(i++, BpUtil.strToDate(fileDate));
            
            rs = query.getRecordList();
        } catch (Exception e) {
            logger.error(e.getMessage());
            //$ERROR:TD00030==�ֽ�����ֽ��ί���±��ļ�״̬��ѯ�쳣==�ֽ�����ֽ��ί���±��ļ�״̬��ѯ�쳣
            throw new AppException("TD00030");
        }
        // װ�������ΪXmlList����ֵ�����ص�XmlList����
        return RecordUtil.getXmlListFromRecordList(rs, CashConstant.RETURN_LIST_NAME);

    }
    
    /**
     * Title: qryTranDetailStt
     * Description:  �ֽ�����ֽ��ί���±��ļ�״̬����
     * @param fileDate
     * @return 
     * date: 2015-12-18 ����04:05:39
     * @author raoxiang
     */
     public int insertTranDetailStt(String fileDate,String detailMonth, String stt) throws AppException{
         int rs = -1;
         StringBuilder builder = new StringBuilder();
         builder.append(" INSERT ");
         builder.append(" INTO ");
         builder.append(" PL_TRN_FILE_STT ");
         builder.append(" ( ");
         builder.append(" PTFS_FILEDATE, ");
         builder.append(" PTFS_DETAILMONTH, ");
         builder.append(" PTFS_PROCESSDATE, ");
         builder.append(" PTFS_STT ");
         builder.append(" ) ");
         builder.append(" VALUES ");
         builder.append(" (?,?,?,?) ");

         try {
             IndexUpdate update = dbSession.createIndexUpdate(builder.toString());
             int i = 1;
             update.setDate(i++, BpUtil.strToDate(fileDate)); 
             update.setString(i++, detailMonth);
             update.setDate(i++, BpUtil.strToDate(MyDate.getFormatDate("yyyyMMdd"))); 
             update.setString(i++, stt);
                          
             rs = update.execute();
         } catch (Exception e) {
             logger.error(e.getMessage());
             //$ERROR:TD00031==�ֽ�����ֽ��ί���±��ļ�״̬�����쳣==�ֽ�����ֽ��ί���±��ļ�״̬�����쳣
             throw new AppException("TD00031");
         }
         return rs;
     }

     /**
      *  ����±���ϸ��Ϣ
      * @param detailMonth ���������ϸ�·�
      * @return
      * @throws AppException
      */
    public int deleteDetailInfo(String detailMonth) throws AppException{
        int rs = -1;
        String avoidLogSql = "ALTER TABLE PL_POOL_TRN_INFO ACTIVATE NOT LOGGED INITIALLY";
        
        StringBuilder builder = new StringBuilder();
        builder.append(" DELETE ");
        builder.append(" FROM ");
        builder.append(" PL_POOL_TRN_INFO ");
        builder.append(" WHERE ");
        builder.append(" PPTI_DETAILMONTH = ? ");

        try {
            //���ò���¼��־
            IndexUpdate avoidLogUpdate = dbSession.createIndexUpdate(avoidLogSql);
            avoidLogUpdate.execute(); 
            //ɾ����ϸ�±���Ϣ
            IndexUpdate update = dbSession.createIndexUpdate(builder.toString());
            int i = 1;
            update.setString(i++, detailMonth); 
            rs = update.execute();
        } catch (Exception e) {
            logger.error(e.getMessage());
            //$ERROR:TD00032==�ֽ�����ֽ��ί���±���ϸ���ʧ��==�ֽ�����ֽ��ί���±���ϸ���ʧ��
            throw new AppException("TD00032");
        }
        return rs;
    }

    /**
    * Title: insertTranDetailInfo
    * Description: �����±���ϸ��
    * @param con
    * @param transDetailInfoDAOBeanList
    * @param i 
    * 2015-12-20 ����1:06:31
    * author: raoxiang 
    */
    public void insertTranDetailInfo(Connection con,
            List<PlPoolTrnInfoBean> transDetailInfoDAOBeanList, int lineNo)throws AppException {
        PreparedStatement pre = null;
        StringBuffer builder = null;
        try {
            builder = new StringBuffer();
            builder.append(" INSERT ");
            builder.append(" INTO ");
            builder.append(" PL_POOL_TRN_INFO ");
            builder.append(" ( ");
            builder.append(" PPTI_BORSETACCOUNT, ");
            builder.append(" PPTI_CONSETACCOUNT, ");
            builder.append(" PPTI_DETAILDATE, ");
            builder.append(" PPTI_DETAILMONTH, ");
            builder.append(" PPTI_BANKNO, ");
            builder.append(" PPTI_POOLID, ");
            builder.append(" PPTI_POOLNAME, ");
            builder.append(" PPTI_BORSETACCOUNTNM, ");
            builder.append(" PPTI_CONSETACCOUNTNM, ");
            builder.append(" PPTI_LASTMONTHBALANCE, ");
            builder.append(" PPTI_DPAMT, ");
            builder.append(" PPTI_LNAMT, ");
            builder.append(" PPTI_AMTSURPLUS, ");
            builder.append(" PPTI_SURPLUSCHANGEDATE, ");
            builder.append(" PPTI_DPRATE, ");
            builder.append(" PPTI_LNRATE, ");
            builder.append(" PPTI_INTEREST, ");
            builder.append(" PPTI_TOTALINTEREST, ");
            builder.append(" PPTI_DPINTEREST, ");
            builder.append(" PPTI_LNINTEREST ");
            builder.append(" ) ");
            builder.append(" VALUES ");
            builder.append(" (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");

            int size = transDetailInfoDAOBeanList.size();
            int j = 0;
            PlPoolTrnInfoBean bean = null;
            if (size != 0) {
                pre = con.prepareStatement(builder.toString());
                for (int i = 0; i < size; i++) {
                    j = 1;
                    bean = transDetailInfoDAOBeanList.get(i);
                    pre.setString(j++,bean.getBorsetaccount());
                    pre.setString(j++,bean.getConsetaccount());
                    pre.setDate(j++,BpUtil.strToDateNew(bean.getDetaildate()));
                    pre.setString(j++,bean.getDetailmonth());
                    pre.setString(j++,bean.getBankno());
                    pre.setString(j++,bean.getPoolid());
                    pre.setString(j++,bean.getPoolname());
                    pre.setString(j++,bean.getBorsetaccountnm());
                    pre.setString(j++,bean.getConsetaccountnm());
                    pre.setString(j++,BpUtil.rmPrePositive(bean.getLastmonthbalance()));
                    pre.setString(j++,BpUtil.rmPrePositive(bean.getDpamt()));
                    pre.setString(j++,BpUtil.rmPrePositive(bean.getLnamt()));
                    pre.setString(j++,BpUtil.rmPrePositive(bean.getAmtsurplus()));
                    pre.setInt(j++,Integer.parseInt(bean.getSurpluschangedate()));
                    pre.setString(j++,BpUtil.rmPrePositive(bean.getDprate()));
                    pre.setString(j++,BpUtil.rmPrePositive(bean.getLnrate()));
                    pre.setString(j++,BpUtil.rmPrePositive(bean.getInterest()));
                    pre.setString(j++,BpUtil.rmPrePositive(bean.getTotalinterest()));
                    pre.setString(j++,BpUtil.rmPrePositive(bean.getDpinterest()));
                    pre.setString(j++,BpUtil.rmPrePositive(bean.getLninterest()));
                    pre.addBatch();
                }
                pre.executeBatch();
            }
            
        } catch (SQLException ae) {
            logger.error("sql :" + builder);
            if (ae instanceof BatchUpdateException) {
                int[] updateCounts = ((BatchUpdateException) ae).getUpdateCounts();
                for (int i = 0; i < updateCounts.length; i++) {
                    if (updateCounts[i] == Statement.EXECUTE_FAILED) {
                        int errorNo = lineNo + i + 1;
                        logger.error("Insert Trans Detail error in line:" + errorNo);
                        break;
                    }
                }
            }
            logger.error(ae.getStackTrace(), ae);
            logger.error(ae.getNextException().getStackTrace(), ae.getNextException());
            //$ERROR:TD00033==�ֽ�����ֽ��ί���±���ϸ����ʧ��==�ֽ�����ֽ��ί���±���ϸ����ʧ��
            throw new AppException("TD00033");
        } catch (Exception e) {
            logger.error("sql :" + builder);
            logger.error(e.getStackTrace(), e);
            //$ERROR:TD00033==�ֽ�����ֽ��ί���±���ϸ����ʧ��==�ֽ�����ֽ��ί���±���ϸ����ʧ��
            throw new AppException("TD00033");
        } finally {
            if (pre != null) {
                try {
                    pre.close();
                } catch (SQLException e) {
                    logger.error(e.getStackTrace(), e);
                }
            }
            
        }
        
    }

    /**
    * Title: updateTranDetailStt
    * Description: �ֽ�����ֽ��ί���±��ļ�״̬�޸�
    * @param fileDate
    * @param stt
    * @param upFlag 
    * 2015-12-20 ����1:48:00
    * author: raoxiang 
    */
    public void updateTranDetailStt(String fileDate, String stt, boolean upFlag)throws AppException {
        if(upFlag){
            int rs = -1;
            StringBuilder builder = new StringBuilder();
            builder.append(" UPDATE ");
            builder.append(" PL_TRN_FILE_STT ");
            builder.append(" SET PTFS_STT = ? ,");
            builder.append(" PTFS_PROCESSDATE = ? ");
            builder.append(" WHERE PTFS_FILEDATE = ? ");

            try {
                IndexUpdate update = dbSession.createIndexUpdate(builder.toString());
                int i = 1;
                update.setString(i++, stt); 
                update.setDate(i++, BpUtil.strToDate(MyDate.getFormatDate("yyyyMMdd"))); 
                update.setDate(i++, BpUtil.strToDate(fileDate)); 
                rs = update.execute();
            } catch (Exception e) {
                logger.error(e.getMessage());
                //$ERROR:TD00034==�ֽ�����ֽ��ί���±��ļ�״̬�޸��쳣==�ֽ�����ֽ��ί���±��ļ�״̬�޸��쳣
                throw new AppException("TD00034");
            }
        }
        
    }
     
    
}
